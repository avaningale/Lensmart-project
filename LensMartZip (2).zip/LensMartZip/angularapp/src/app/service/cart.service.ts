import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {
public cartItemList:any=[]
public productsList = new BehaviorSubject<any>([]);

  constructor() { }
  getProducts(){
   var test = this.productsList.asObservable();
   console.log(test);
   return test;
  }
  setProduct(product : any){
    this.cartItemList.push(...product);
    this.productsList.next(product);
  }
  addtoCart(product : any){
    this.cartItemList.push(product);
    this.productsList.next(this.cartItemList);
    this.getTotalPrice();
    console.log(this.cartItemList)
  }
  getTotalPrice():number{
    let grandTotal = 0;
    this.cartItemList.map((a:any)=>{
      grandTotal += a.total;
    })
    return grandTotal;
  }
  removeCartItem(product:any)
  {
    this.cartItemList.map((a:any,index:any)=>{
      if(product.id===a.id){      //checks the product id to remove the product
        this.cartItemList.splice(index,1);
      }
    })
    this.productsList.next(this.cartItemList);
  }removeallcart(){
    this.cartItemList = []
    this.productsList.next(this.cartItemList);
  }
}
