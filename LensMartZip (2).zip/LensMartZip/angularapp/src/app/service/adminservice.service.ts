import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { admin, adminid } from 'src/app/Models/Admin.modal';

@Injectable({
  providedIn: 'root'
})
export class AdminserviceService {

  baseUrl='https://localhost:7024/api/Product/Read';

 public  createurl='https://localhost:7024/api/Product/Create';

  public deleteurl:string='https://localhost:7024/api/Product/Delete?ProductId';

  


  constructor(private http: HttpClient) { }


  //get all cards
  getAllProducts(): Observable<admin[]>{
     return this.http.get<admin[]>(this.baseUrl);
  }

  Create(lensmart:admin): Observable<any>{
   // lensmart.productid='00000000-0000-0000-0000-000000000000s';
    return this.http.post(this.createurl,lensmart);
  }

  Delete(productId:any) 
  {
    console.log(`${this.deleteurl}=${productId}`);
    return this.http.delete(`${this.deleteurl}=${productId}`); 
  }
}
