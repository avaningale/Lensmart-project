﻿using LensMart.Models;
using Microsoft.AspNetCore.Mvc;

namespace LensMart.Core.Interface
{
    public interface ISignUp
    {
        string RegisterUser(UserModel userModel);
      
    }
}
