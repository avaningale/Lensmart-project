﻿using LensMart.Models;

namespace LensMart.Core.Interface
{
    public interface IOrder

    {
       List<OrderModel> GetUserProducts(int Id);
        //List<ResponseModel> SaveProduct(int Id);

        int PlaceOrder(OrderModel order);
        string SaveProduct( int id);

    }
}
