﻿using LensMart.Models;

namespace LensMart.Core.Interface
{
    public interface ICart
    {
        ResponseModel AddToCart(int  id,int quanttity);
        ResponseModel DeleteCartItem(int id);
        List<CartModel> ShowCart();
    }
}
