﻿using LensMart.Context;
using LensMart.Core.Interface;
using LensMart.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using NuGet.Protocol.Plugins;
using System.Linq;
using System.Collections.Generic;

namespace LensMart.Core
{
    public class OrderCore : IOrder
    {
        private readonly LensContext Context;
        public OrderCore(LensContext Context)
        {
            this.Context = Context;

        }

        public List<OrderModel> GetUserProducts(int Id)
        {
            try
            {
               

                var order = Context.OrderTable.Find(Id);

                if (order != null)
                {
                 return  Context.OrderTable.ToList();  

                }
                throw new Exception("Enter the valid product id");

            }
            catch (Exception)
            {

                throw;
            }

        }

        public int PlaceOrder(OrderModel order)
        {
            try
            {
                if (order != null)
                {
                 var orderresponse=  Context.OrderTable.Add(order);
                 Context.SaveChanges();
                }
                throw new Exception("order not found");
            }
            catch (Exception)
            {

                throw;
            }
        }

        public string  SaveProduct( int id )
        {
            
            try
            {
               
                var orderItem = Context.CartTable.FirstOrDefault(i => i.cartitemId == id);
                if (orderItem != null)
                {

                    var product = new OrderModel
                    {
                        ProductName = orderItem.ProductName,
                        price = orderItem.Price,
                        Quantity = orderItem.Quantity,


                    }; 
                    Context.SaveChanges();
                     
                   

                   
                }
                
                throw new Exception("Enter valid cart Id");

            }
            catch (Exception )
            {

                throw; 
            }
        }

        
    }
}


    
