﻿using LensMart.Context;
using LensMart.Core.Interface;
using LensMart.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace LensMart.Core
{
    public class SignUpCore : ISignUp
    {

        private readonly LensContext context;
        private readonly IConfiguration configuration;

        public SignUpCore(LensContext context, IConfiguration configuration)
        {
            this.context = context;
            this.configuration = configuration;
        }


        public string RegisterUser([FromBody] UserModel userModel)
        {

            try
            {
                
                var response = context.UserTable.Add(userModel);
                context.SaveChanges();
                
                if (response != null)
                {
                    return "Sucessfully Registered";

                }
                else
                {
                    return "Enter Proper Detail";
                }


            }
            catch (Exception)
            {

                throw;
            }
        }
       
    }
}
