﻿
using LensMart.Context;
using LensMart.Core.Interface;
using LensMart.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace LensMart.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        
        private readonly ICart cart;
        public  CartController(ICart cart)
        {
            this.cart = cart;
         
        }       
        [HttpPost]
        [Route("AddToCart")]
        public ResponseModel AddToCart(int ProductId, int Quantity)
        {
            try
            {
                ResponseModel responseModel= new ResponseModel();   
                var Cartitem= cart.AddToCart(ProductId,Quantity);
                responseModel.Response = Cartitem;
                responseModel.Status = true;
                responseModel.Message = "Added";
                return responseModel;
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpDelete]
        [Route("deleteCartItem")]
        public ResponseModel deleteCartItem(int CartItemId)
        {
            try
            {
                ResponseModel responseModel= new ResponseModel();
               var cartitem = cart.DeleteCartItem(CartItemId);
                responseModel.Response = cartitem;
                responseModel.Status = true;
                responseModel.Message = "Deleted";
                return responseModel;
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpGet]
        [Route("ShowCart")]
        public ActionResult<List<CartModel>>ShowCart()
        {
            try
            {
               
                var cartitem = cart.ShowCart();
                return cartitem;

            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
