﻿using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LensMart.Models
{
    public class UserModel
    {
        [Key]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }
        [Required]
        [MinLength(6)]
        public string Password { get; set; }

        [Required, MaxLength(255)]
        public string UserName { get; set; }
        [Required]
        public string MobileNumber { get; set; }
        [Required]
        public string role { get; set; }

        //[NotMapped]
        [System.Text.Json.Serialization.JsonIgnore]
        public virtual ICollection<OrderModel>? Orders { get; set; }
       

        

    }
}
